int main(void){
    char *s = "hello world";
    *s = 'H';
}
