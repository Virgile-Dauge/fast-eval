int main(){printf("coucou"); return 0;}
