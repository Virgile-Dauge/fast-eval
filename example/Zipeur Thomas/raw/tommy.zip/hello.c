int main(){printf("coucou\n"); return 0;}
