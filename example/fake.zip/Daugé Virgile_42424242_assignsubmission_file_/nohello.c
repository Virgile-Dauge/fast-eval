int main(){ char * msg = "nohello"; return 0;}
