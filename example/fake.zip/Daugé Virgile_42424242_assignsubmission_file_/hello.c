int main(){printf("coucou\n"); oups = "1"; return 0;}
